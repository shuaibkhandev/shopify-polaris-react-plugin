
import OurApps from "./OurApps";
import HeroSec from "./HeroSec";



const Recommendations = () => {
  return (
    <div>  
 <HeroSec/>
  <OurApps/>
    </div>
  );
};

export default Recommendations;
